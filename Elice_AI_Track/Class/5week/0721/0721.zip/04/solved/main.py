# HASH란 무엇인지 살펴봅시다 :)

import secrets
from werkzeug.security import generate_password_hash, check_password_hash

print(secrets.token_hex(16))

pw = "elice"
pw_hash1 = generate_password_hash(pw)
pw_hash2 = generate_password_hash(pw)
print(pw_hash1)
print(pw_hash2)

print(check_password_hash(pw_hash1, pw))
print(check_password_hash(pw_hash2, pw))
