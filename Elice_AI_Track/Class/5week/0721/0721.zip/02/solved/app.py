from flask import Flask, render_template, jsonify, request
from pymongo import MongoClient

app = Flask(__name__)

client = MongoClient('localhost', 27017)

# 디비 생성
db = client.elice

# 컬렉션 생성
memos = db.memos

# 데이터가 들어가기전에는 디비와 컬렉션이 생성되지 않음
print(client.list_database_names())
print(db.list_collection_names())


@app.route('/')
def home():
    return render_template('index.html')


@app.route('/memo', methods=['POST'])
def post_memo():
    # 0. 사용자가 보낸 데이터를 변수에 답아봅시다!
    title = request.form["title_give"]
    memo = request.form["memo_give"]

    # 1. db에 넣을 딕셔너리를 하나 만들어보아요.
    new_memo = {
        'title':title,
        'memo':memo,
    }
    # 2. 위에서 정의한 db에 Create를 해봅시다.
    memos.insert_one(new_memo)

    # 3. db에 데이터를 넣었으면 성공메시지를 보내줍시다!
    return jsonify({'result': 'success'})


@app.route('/memo', methods=['GET'])
def read_memo():
    # # 1. db에 저장된 데이터를 가져옵시다.
    find_memos = memos.find({},{'_id':False})

    # 2. 가져온 데이터를 jsonify를 통해 다시 보내줍시다!
    return jsonify({'result': 'success','memos':find_memos})


if __name__ == '__main__':
    app.run(debug=True)