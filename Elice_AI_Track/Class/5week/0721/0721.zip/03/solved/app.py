from flask import Flask, render_template, jsonify, request
import requests
from bs4 import BeautifulSoup

app = Flask(__name__)

def parse_stock_price(stock_code):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.368'}
    url = f"https://finance.naver.com/item/main.nhn?code={stock_code}"
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        print("Unable to crawl the page : ", response.status_code)
        return
    
    soup = BeautifulSoup(response.text,'html.parser')

    select = soup.select("dl.blind > dd")
    
    print(select)
    price = None

    for value in select:
        split = value.text.split(" ")
        if split[0] == "현재가":
            price = split[1]

    return price


@app.route('/')
def home():
    return render_template('index.html')

@app.route('/stock', methods=["POST"])
def get_stock():
    stock_code = request.form["stockCode"]
    price = parse_stock_price(stock_code)
    
    if price:
        return jsonify({"result":"success","price":price})
    else:
        return jsonify({"result":"failed","msg":"해당 종목이 존재하지 않습니다."})

parse_stock_price('005930')
if __name__ == '__main__':
    
    app.run(debug=True)
