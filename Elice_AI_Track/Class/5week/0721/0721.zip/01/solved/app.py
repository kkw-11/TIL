from flask import Flask, render_template, jsonify, request, redirect, url_for, Response

app = Flask(__name__)

names = ['John', 'Jane', "Elice"]


@app.route('/')
def index():
    return render_template('index.html')


'''
user GET, POST, DELETE 구현
- GET : 화면을 보여주고, names를 
- POST : names에 username 추가
- DELETE : names에서 username 삭제
'''
@app.route('/user', methods=["GET","POST","DELETE","PATCH"])
def user():
    if request.method == "POST":
        username = request.form["username"]
        if username not in names:
            names.append(username)
    elif request.method == "DELETE":
        username = request.form["username"]
        if username in names:
            names.remove(username)
            return jsonify(result="success")
        else:
            return jsonify(result="failed",err="사용자가 존재하지 않습니다.")
    elif request.method == "PATCH":
        username = request.form["username"]
        new_username = request.form["new_username"]
        if username in names:
            idx = names.index(username)
            names[idx] = new_username
            return jsonify(result="success")
        else:
            return jsonify(result="failed",err="사용자가 존재하지 않습니다.")
    return render_template("user.html",names=names)

if __name__ == '__main__':
    app.run(debug=True)
