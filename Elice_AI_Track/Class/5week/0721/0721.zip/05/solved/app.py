# JWT에 대해서 알아봅시다.

from flask import Flask, request, jsonify, url_for, render_template, redirect
from flask_jwt_extended import (
    JWTManager, jwt_required, create_access_token,get_jwt_identity
)
from datetime import timedelta


app = Flask(__name__)
# 해시 암호화에 사용한 SECRET_KEY
app.config['SECRET_KEY'] = 'bee11777d0d22065bdb8fc7edafb0557'
# 토큰 만료 시간 설정
ACCESS_TOKEN_EXPIRE_MINUTES = 2
# JMTManager를 통해, app에 대한 JWTManager 인스턴스 생성
jwt = JWTManager(app)


@app.route('/login', methods=['GET', 'POST'])
def login():
    username = request.form['username']
    password = request.form['password']

    # 토큰의 expire 기한(deadline)을 timedelta 객체 인스턴스 형태로 만들어 변수에 저장
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)

    # 액세스 토큰을 생성
    access_token = create_access_token(
        identity=username, expires_delta=access_token_expires)
    return jsonify(access_token=access_token) # access token 발급해서 response.json 객체로 전달

@app.route('/')
def index():
    return render_template("index.html")


@app.route('/protected')
@jwt_required()
def protected():
    print("Welcome to VIP zone!")
    current_user = get_jwt_identity()
    return jsonify(result="success",logged_in_as=current_user)

if __name__ == '__main__':
    print(__name__)
    app.run(debug=True)